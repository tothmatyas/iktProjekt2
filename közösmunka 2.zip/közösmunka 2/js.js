
const components = document.querySelectorAll('.component')
const selectedContainer = document.getElementById('selected')
const totalDiv = document.getElementById('total')
const orderButton = document.getElementById('orderButton')
const errorDiv = document.getElementById('error')

let totalPrice = 0;
let selectedItems = {}

components.forEach(component => {
    component.addEventListener('click', () => {

        const name = component.dataset.name

        const price = parseInt(component.dataset.price, 10)

        if (selectedItems[name]) {
            delete selectedItems[name];
            totalPrice -= price;
            component.classList.remove('selected')
        } 
        
        else {
            selectedItems[name] = price
            totalPrice += price
            component.classList.add('selected')
        }

        updateSelected()
    })
})

function updateSelected() {

    selectedContainer.innerHTML = ''
    for (const name in selectedItems) {
        const itemDiv = document.createElement('div')
        itemDiv.className = 'selected-item'
        itemDiv.textContent = `${name} - $${selectedItems[name]}`
        selectedContainer.appendChild(itemDiv)
    }

    totalDiv.textContent = `Total Price: $${totalPrice}`
}

orderButton.addEventListener('click', () => {
    const required = ['CPU', 'Motherboard', 'RAM', 'Storage', 'GPU']
    
    const missing = required.filter(item => !selectedItems[item])

    if (missing.length > 0) {
        errorDiv.textContent = `Hiányzó alkatrészek: ${missing.join(', ')}`
    } 
    else {
        errorDiv.textContent = ''
        alert('Sikeres Rendlelés!')
    }
})

function applyRecommendation(recommendedComponents) {
    components.forEach(component => {
        const name = component.dataset.name
        const price = parseInt(component.dataset.price, 10)

        if (recommendedComponents.includes(name)) {
            if (!selectedItems[name]) {
                selectedItems[name] = price
                totalPrice += price
                component.classList.add('selected')
            }
        } else {
            if (selectedItems[name]) {
                delete selectedItems[name]
                totalPrice -= price
                component.classList.remove('selected')
            }
        }
    })

    updateSelected()
}
